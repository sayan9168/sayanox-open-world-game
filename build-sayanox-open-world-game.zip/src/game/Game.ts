import type { GameState, Stats, StatsCallback, StateCallback } from "./types";

// ---------- helpers ----------
const rand = (a: number, b: number) => a + Math.random() * (b - a);
const clamp = (v: number, a: number, b: number) => (v < a ? a : v > b ? b : v);
const lerp = (a: number, b: number, t: number) => a + (b - a) * t;
const dist2 = (ax: number, ay: number, bx: number, by: number) => {
  const dx = ax - bx;
  const dy = ay - by;
  return dx * dx + dy * dy;
};

const HS_KEY = "sayanox-highscores-v1";

interface Vec {
  x: number;
  y: number;
}

interface Particle {
  x: number;
  y: number;
  vx: number;
  vy: number;
  life: number;
  maxLife: number;
  size: number;
  color: string;
  glow: boolean;
  drag: number;
}

interface Crystal {
  x: number;
  y: number;
  phase: number;
  big: boolean;
  alive: boolean;
}

interface Enemy {
  x: number;
  y: number;
  vx: number;
  vy: number;
  r: number;
  hp: number;
  maxHp: number;
  spawn: number; // spawn animation 0..1
  hitFlash: number;
  kind: "chaser" | "brute";
  wobble: number;
}

const WORLD = 3200; // half-size; world spans -WORLD..WORLD

export class Game {
  private canvas: HTMLCanvasElement;
  private ctx: CanvasRenderingContext2D;
  private dpr = 1;
  private vw = 0; // viewport css px
  private vh = 0;

  private raf = 0;
  private lastT = 0;
  private running = false;

  state: GameState = "menu";

  // camera
  private cam: Vec = { x: 0, y: 0 };
  private shake = 0;
  private shakeX = 0;
  private shakeY = 0;
  private flash = 0; // white/damage flash 0..1
  private flashColor = "255,80,120";
  private hitStop = 0;
  private pulse = 0; // collect pulse

  // player
  private p = {
    x: 0,
    y: 0,
    vx: 0,
    vy: 0,
    r: 16,
    angle: 0,
    health: 5,
    maxHealth: 5,
    dashCd: 0,
    dashMax: 1.1,
    dashing: 0,
    invuln: 0,
    trail: 0,
    heal: 0,
  };

  // world objects
  private crystals: Crystal[] = [];
  private enemies: Enemy[] = [];
  private particles: Particle[] = [];
  private stars: { x: number; y: number; z: number }[] = [];

  // gameplay
  private score = 0;
  private best = 0;
  private combo = 0;
  private comboTimer = 0;
  private comboMax = 2.2;
  private time = 0;
  private spawnTimer = 0;
  private collected = 0;
  private wave = 1;
  private floatTexts: { x: number; y: number; text: string; life: number; color: string; vy: number }[] = [];

  // input
  private keys: Record<string, boolean> = {};
  private moveVec: Vec = { x: 0, y: 0 };
  private joyActive = false;
  private joyId = -1;
  private joyBase: Vec = { x: 0, y: 0 };
  private joyKnob: Vec = { x: 0, y: 0 };
  private dashQueued = false;

  private statsCb: StatsCallback | null = null;
  private stateCb: StateCallback | null = null;
  private lastStatEmit = 0;

  constructor(canvas: HTMLCanvasElement) {
    this.canvas = canvas;
    this.ctx = canvas.getContext("2d", { alpha: false })!;
    this.best = this.loadBest();
    this.resize();
    this.attach();
  }

  // ---------- public API ----------
  onStats(cb: StatsCallback) {
    this.statsCb = cb;
  }
  onState(cb: StateCallback) {
    this.stateCb = cb;
  }

  private setState(s: GameState) {
    this.state = s;
    this.stateCb?.(s);
  }

  start() {
    this.reset();
    this.setState("playing");
    if (!this.running) {
      this.running = true;
      this.lastT = performance.now();
      this.raf = requestAnimationFrame(this.loop);
    }
  }

  pause() {
    if (this.state === "playing") this.setState("paused");
  }
  resume() {
    if (this.state === "paused") {
      this.setState("playing");
      this.lastT = performance.now();
    }
  }
  togglePause() {
    if (this.state === "playing") this.pause();
    else if (this.state === "paused") this.resume();
  }
  restart() {
    this.start();
  }

  destroy() {
    cancelAnimationFrame(this.raf);
    this.running = false;
    this.detach();
  }

  // ---------- setup ----------
  private reset() {
    this.p.x = 0;
    this.p.y = 0;
    this.p.vx = 0;
    this.p.vy = 0;
    this.p.health = this.p.maxHealth;
    this.p.dashCd = 0;
    this.p.dashing = 0;
    this.p.invuln = 0;
    this.p.heal = 0;
    this.cam.x = 0;
    this.cam.y = 0;
    this.score = 0;
    this.combo = 0;
    this.comboTimer = 0;
    this.time = 0;
    this.spawnTimer = 1.2;
    this.collected = 0;
    this.wave = 1;
    this.shake = 0;
    this.flash = 0;
    this.enemies = [];
    this.particles = [];
    this.floatTexts = [];
    this.crystals = [];
    for (let i = 0; i < 130; i++) this.crystals.push(this.newCrystal());
    // ensure some near spawn for instant fun
    for (let i = 0; i < 10; i++) {
      const a = (i / 10) * Math.PI * 2;
      const d = rand(120, 320);
      this.crystals[i].x = Math.cos(a) * d;
      this.crystals[i].y = Math.sin(a) * d;
    }
    if (this.stars.length === 0) {
      for (let i = 0; i < 220; i++) {
        this.stars.push({ x: rand(-WORLD, WORLD), y: rand(-WORLD, WORLD), z: rand(0.2, 1) });
      }
    }
  }

  private newCrystal(): Crystal {
    let x = 0;
    let y = 0;
    // avoid spawning right on player
    for (let i = 0; i < 8; i++) {
      x = rand(-WORLD + 100, WORLD - 100);
      y = rand(-WORLD + 100, WORLD - 100);
      if (dist2(x, y, this.p.x, this.p.y) > 300 * 300) break;
    }
    return { x, y, phase: rand(0, Math.PI * 2), big: Math.random() < 0.12, alive: true };
  }

  // ---------- input ----------
  private attach() {
    window.addEventListener("keydown", this.onKeyDown);
    window.addEventListener("keyup", this.onKeyUp);
    window.addEventListener("resize", this.resize);
    this.canvas.addEventListener("pointerdown", this.onPointerDown);
    this.canvas.addEventListener("pointermove", this.onPointerMove);
    this.canvas.addEventListener("pointerup", this.onPointerUp);
    this.canvas.addEventListener("pointercancel", this.onPointerUp);
  }
  private detach() {
    window.removeEventListener("keydown", this.onKeyDown);
    window.removeEventListener("keyup", this.onKeyUp);
    window.removeEventListener("resize", this.resize);
    this.canvas.removeEventListener("pointerdown", this.onPointerDown);
    this.canvas.removeEventListener("pointermove", this.onPointerMove);
    this.canvas.removeEventListener("pointerup", this.onPointerUp);
    this.canvas.removeEventListener("pointercancel", this.onPointerUp);
  }

  private onKeyDown = (e: KeyboardEvent) => {
    const k = e.key.toLowerCase();
    if (["arrowup", "arrowdown", "arrowleft", "arrowright", " "].includes(k)) e.preventDefault();
    this.keys[k] = true;
    if (k === " " || k === "shift") this.dashQueued = true;
    if (k === "p" || k === "escape") this.togglePause();
    if ((k === "enter" || k === " ") && this.state === "gameover") this.start();
  };
  private onKeyUp = (e: KeyboardEvent) => {
    this.keys[e.key.toLowerCase()] = false;
  };

  private onPointerDown = (e: PointerEvent) => {
    const rect = this.canvas.getBoundingClientRect();
    const x = e.clientX - rect.left;
    const y = e.clientY - rect.top;
    if (this.state !== "playing") return;
    if (x < this.vw * 0.5) {
      // left = joystick
      this.joyActive = true;
      this.joyId = e.pointerId;
      this.joyBase = { x, y };
      this.joyKnob = { x, y };
    } else {
      // right = dash
      this.dashQueued = true;
    }
  };
  private onPointerMove = (e: PointerEvent) => {
    if (!this.joyActive || e.pointerId !== this.joyId) return;
    const rect = this.canvas.getBoundingClientRect();
    const x = e.clientX - rect.left;
    const y = e.clientY - rect.top;
    let dx = x - this.joyBase.x;
    let dy = y - this.joyBase.y;
    const max = 60;
    const d = Math.hypot(dx, dy);
    if (d > max) {
      dx = (dx / d) * max;
      dy = (dy / d) * max;
    }
    this.joyKnob = { x: this.joyBase.x + dx, y: this.joyBase.y + dy };
    this.moveVec = { x: dx / max, y: dy / max };
  };
  private onPointerUp = (e: PointerEvent) => {
    if (e.pointerId === this.joyId) {
      this.joyActive = false;
      this.joyId = -1;
      this.moveVec = { x: 0, y: 0 };
    }
  };

  // external dash for UI button
  triggerDash() {
    this.dashQueued = true;
  }

  private resize = () => {
    this.dpr = Math.min(window.devicePixelRatio || 1, 2);
    const parent = this.canvas.parentElement;
    this.vw = parent ? parent.clientWidth : window.innerWidth;
    this.vh = parent ? parent.clientHeight : window.innerHeight;
    this.canvas.width = Math.floor(this.vw * this.dpr);
    this.canvas.height = Math.floor(this.vh * this.dpr);
    this.canvas.style.width = this.vw + "px";
    this.canvas.style.height = this.vh + "px";
  };

  // ---------- loop ----------
  private loop = (t: number) => {
    if (!this.running) return;
    let dt = (t - this.lastT) / 1000;
    this.lastT = t;
    if (dt > 0.05) dt = 0.05; // clamp big gaps
    if (this.state === "playing") {
      if (this.hitStop > 0) {
        this.hitStop -= dt;
      } else {
        this.update(dt);
      }
    }
    this.render();
    this.emitStats(t);
    this.raf = requestAnimationFrame(this.loop);
  };

  private emitStats(t: number) {
    if (t - this.lastStatEmit < 80) return;
    this.lastStatEmit = t;
    const s: Stats = {
      score: Math.floor(this.score),
      best: Math.max(this.best, Math.floor(this.score)),
      combo: this.combo,
      comboTimer: this.comboTimer / this.comboMax,
      health: this.p.health,
      maxHealth: this.p.maxHealth,
      dash: clamp(1 - this.p.dashCd / this.p.dashMax, 0, 1),
      time: this.time,
      wave: this.wave,
    };
    this.statsCb?.(s);
  }

  // ---------- update ----------
  private update(dt: number) {
    this.time += dt;
    const p = this.p;

    // input vector
    let ix = this.moveVec.x;
    let iy = this.moveVec.y;
    if (this.keys["arrowleft"] || this.keys["a"]) ix -= 1;
    if (this.keys["arrowright"] || this.keys["d"]) ix += 1;
    if (this.keys["arrowup"] || this.keys["w"]) iy -= 1;
    if (this.keys["arrowdown"] || this.keys["s"]) iy += 1;
    const il = Math.hypot(ix, iy);
    if (il > 1) {
      ix /= il;
      iy /= il;
    }

    // dash
    p.dashCd = Math.max(0, p.dashCd - dt);
    if (this.dashQueued && p.dashCd <= 0 && (il > 0.05 || p.dashing > 0)) {
      // dash in movement dir, or facing dir if no input
      let dx = ix;
      let dy = iy;
      if (Math.hypot(dx, dy) < 0.05) {
        dx = Math.cos(p.angle);
        dy = Math.sin(p.angle);
      }
      const dl = Math.hypot(dx, dy) || 1;
      p.vx += (dx / dl) * 900;
      p.vy += (dy / dl) * 900;
      p.dashing = 0.22;
      p.invuln = Math.max(p.invuln, 0.28);
      p.dashCd = p.dashMax;
      this.addShake(6);
      // dash burst particles
      for (let i = 0; i < 18; i++) {
        const a = Math.atan2(dy, dx) + Math.PI + rand(-0.6, 0.6);
        const sp = rand(60, 320);
        this.particles.push({
          x: p.x,
          y: p.y,
          vx: Math.cos(a) * sp,
          vy: Math.sin(a) * sp,
          life: rand(0.25, 0.6),
          maxLife: 0.6,
          size: rand(2, 5),
          color: "150,220,255",
          glow: true,
          drag: 3,
        });
      }
    }
    this.dashQueued = false;
    p.dashing = Math.max(0, p.dashing - dt);

    // movement accel
    const accel = p.dashing > 0 ? 200 : 3200;
    p.vx += ix * accel * dt;
    p.vy += iy * accel * dt;
    // friction
    const fr = p.dashing > 0 ? 1.5 : 9;
    p.vx -= p.vx * Math.min(1, fr * dt);
    p.vy -= p.vy * Math.min(1, fr * dt);
    // cap normal speed
    const maxSpd = p.dashing > 0 ? 1200 : 340;
    const spd = Math.hypot(p.vx, p.vy);
    if (spd > maxSpd) {
      p.vx = (p.vx / spd) * maxSpd;
      p.vy = (p.vy / spd) * maxSpd;
    }
    p.x += p.vx * dt;
    p.y += p.vy * dt;
    // world bounds bounce
    const b = WORLD - 40;
    if (p.x < -b) {
      p.x = -b;
      p.vx *= -0.4;
    }
    if (p.x > b) {
      p.x = b;
      p.vx *= -0.4;
    }
    if (p.y < -b) {
      p.y = -b;
      p.vy *= -0.4;
    }
    if (p.y > b) {
      p.y = b;
      p.vy *= -0.4;
    }
    if (spd > 5) p.angle = Math.atan2(p.vy, p.vx);
    p.invuln = Math.max(0, p.invuln - dt);

    // engine trail
    p.trail -= dt;
    if (spd > 60 && p.trail <= 0) {
      p.trail = 0.02;
      const a = p.angle + Math.PI + rand(-0.3, 0.3);
      this.particles.push({
        x: p.x + Math.cos(a) * 12,
        y: p.y + Math.sin(a) * 12,
        vx: Math.cos(a) * rand(20, 90),
        vy: Math.sin(a) * rand(20, 90),
        life: 0.4,
        maxLife: 0.4,
        size: rand(2, 4.5),
        color: p.dashing > 0 ? "140,210,255" : "255,150,90",
        glow: true,
        drag: 2,
      });
    }

    // camera follow with smoothing
    this.cam.x = lerp(this.cam.x, p.x, clamp(dt * 6, 0, 1));
    this.cam.y = lerp(this.cam.y, p.y, clamp(dt * 6, 0, 1));

    // combo decay
    if (this.comboTimer > 0) {
      this.comboTimer -= dt;
      if (this.comboTimer <= 0) this.combo = 0;
    }

    // crystals
    const pickR2 = (p.r + 26) * (p.r + 26);
    for (const c of this.crystals) {
      if (!c.alive) continue;
      c.phase += dt * 3;
      const d2 = dist2(c.x, c.y, p.x, p.y);
      // magnet
      if (d2 < 150 * 150) {
        const d = Math.sqrt(d2) || 1;
        const pull = (1 - d / 150) * 420;
        c.x += ((p.x - c.x) / d) * pull * dt;
        c.y += ((p.y - c.y) / d) * pull * dt;
      }
      if (d2 < pickR2) {
        this.collectCrystal(c);
      }
    }

    // spawn enemies
    this.wave = 1 + Math.floor(this.time / 20);
    this.spawnTimer -= dt;
    const cap = Math.min(4 + this.wave * 2, 26);
    if (this.spawnTimer <= 0 && this.enemies.length < cap) {
      this.spawnEnemy();
      this.spawnTimer = Math.max(0.5, 2.2 - this.wave * 0.14);
    }

    // enemies update
    for (const e of this.enemies) {
      e.spawn = Math.min(1, e.spawn + dt * 2.5);
      e.hitFlash = Math.max(0, e.hitFlash - dt * 4);
      e.wobble += dt * 6;
      const dx = p.x - e.x;
      const dy = p.y - e.y;
      const d = Math.hypot(dx, dy) || 1;
      const base = e.kind === "brute" ? 70 : 130;
      const sp = base + this.wave * 6;
      e.vx = lerp(e.vx, (dx / d) * sp, clamp(dt * 2, 0, 1));
      e.vy = lerp(e.vy, (dy / d) * sp, clamp(dt * 2, 0, 1));
      // slight orbit wobble
      e.x += e.vx * dt + Math.cos(e.wobble) * 8 * dt;
      e.y += e.vy * dt + Math.sin(e.wobble) * 8 * dt;

      if (e.spawn < 1) continue;
      const rr = (e.r + p.r) * (e.r + p.r);
      if (dist2(e.x, e.y, p.x, p.y) < rr) {
        if (p.dashing > 0 || p.invuln > 0) {
          // destroy on dash contact
          if (p.dashing > 0) {
            this.hurtEnemy(e, 999);
          }
        } else {
          this.hurtPlayer(e);
        }
      }
    }
    // enemy separation (cheap)
    for (let i = 0; i < this.enemies.length; i++) {
      for (let j = i + 1; j < this.enemies.length; j++) {
        const a = this.enemies[i];
        const bb = this.enemies[j];
        const dx = bb.x - a.x;
        const dy = bb.y - a.y;
        const d2 = dx * dx + dy * dy;
        const min = a.r + bb.r;
        if (d2 < min * min && d2 > 0.01) {
          const d = Math.sqrt(d2);
          const push = ((min - d) / d) * 0.5;
          a.x -= dx * push;
          a.y -= dy * push;
          bb.x += dx * push;
          bb.y += dy * push;
        }
      }
    }
    this.enemies = this.enemies.filter((e) => e.hp > 0);

    // particles
    for (const pt of this.particles) {
      pt.life -= dt;
      pt.vx -= pt.vx * Math.min(1, pt.drag * dt);
      pt.vy -= pt.vy * Math.min(1, pt.drag * dt);
      pt.x += pt.vx * dt;
      pt.y += pt.vy * dt;
    }
    if (this.particles.length > 600) this.particles.splice(0, this.particles.length - 600);
    this.particles = this.particles.filter((pt) => pt.life > 0);

    // float texts
    for (const f of this.floatTexts) {
      f.life -= dt;
      f.y += f.vy * dt;
    }
    this.floatTexts = this.floatTexts.filter((f) => f.life > 0);

    // fx decay
    this.shake = Math.max(0, this.shake - dt * 30);
    this.flash = Math.max(0, this.flash - dt * 3);
    this.pulse = Math.max(0, this.pulse - dt * 3);

    // slow regen from heal buffer
    if (p.heal >= 1 && p.health < p.maxHealth) {
      p.heal -= 1;
      p.health += 1;
      this.floatText(p.x, p.y - 30, "+HP", "120,255,180");
    }
  }

  private collectCrystal(c: Crystal) {
    c.alive = false;
    const gain = (c.big ? 25 : 8) * this.comboMultiplier();
    this.score += gain;
    this.collected++;
    this.p.heal += c.big ? 0.5 : 0.14;
    this.pulse = 1;
    this.addShake(c.big ? 4 : 1.5);
    this.floatText(c.x, c.y, "+" + Math.round(gain), c.big ? "255,220,120" : "120,240,255");
    // particles
    const n = c.big ? 24 : 10;
    for (let i = 0; i < n; i++) {
      const a = rand(0, Math.PI * 2);
      const sp = rand(40, c.big ? 320 : 180);
      this.particles.push({
        x: c.x,
        y: c.y,
        vx: Math.cos(a) * sp,
        vy: Math.sin(a) * sp,
        life: rand(0.3, 0.7),
        maxLife: 0.7,
        size: rand(2, c.big ? 6 : 4),
        color: c.big ? "255,220,130" : "120,240,255",
        glow: true,
        drag: 2.5,
      });
    }
    // respawn a fresh one elsewhere
    const nc = this.newCrystal();
    c.x = nc.x;
    c.y = nc.y;
    c.phase = nc.phase;
    c.big = nc.big;
    c.alive = true;
  }

  private comboMultiplier() {
    return 1 + Math.min(this.combo, 12) * 0.25;
  }

  private spawnEnemy() {
    const ang = rand(0, Math.PI * 2);
    const d = Math.max(this.vw, this.vh) * 0.62 + rand(60, 220);
    const brute = Math.random() < Math.min(0.1 + this.wave * 0.03, 0.4);
    this.enemies.push({
      x: this.p.x + Math.cos(ang) * d,
      y: this.p.y + Math.sin(ang) * d,
      vx: 0,
      vy: 0,
      r: brute ? 26 : 15,
      hp: brute ? 3 : 1,
      maxHp: brute ? 3 : 1,
      spawn: 0,
      hitFlash: 0,
      kind: brute ? "brute" : "chaser",
      wobble: rand(0, Math.PI * 2),
    });
  }

  private hurtEnemy(e: Enemy, dmg: number) {
    e.hp -= dmg;
    e.hitFlash = 1;
    if (e.hp <= 0) {
      this.combo++;
      this.comboTimer = this.comboMax;
      const gain = (e.kind === "brute" ? 60 : 20) * this.comboMultiplier();
      this.score += gain;
      this.addShake(e.kind === "brute" ? 12 : 7);
      this.hitStop = 0.045;
      this.flashColor = "255,120,200";
      this.flash = Math.max(this.flash, 0.35);
      this.floatText(e.x, e.y, "+" + Math.round(gain), "255,150,210");
      if (this.combo >= 2) this.floatText(e.x, e.y - 22, "x" + this.combo + " COMBO", "255,220,120");
      this.explode(e.x, e.y, e.kind === "brute" ? 34 : 20, "255,110,170");
    } else {
      this.addShake(3);
      this.explode(e.x, e.y, 8, "255,150,190");
    }
  }

  private hurtPlayer(e: Enemy) {
    const p = this.p;
    p.health -= e.kind === "brute" ? 2 : 1;
    p.invuln = 1.1;
    // knockback
    const dx = p.x - e.x;
    const dy = p.y - e.y;
    const d = Math.hypot(dx, dy) || 1;
    p.vx += (dx / d) * 520;
    p.vy += (dy / d) * 520;
    e.vx -= (dx / d) * 200;
    e.vy -= (dy / d) * 200;
    this.combo = 0;
    this.comboTimer = 0;
    this.addShake(16);
    this.hitStop = 0.06;
    this.flashColor = "255,60,90";
    this.flash = 0.8;
    this.explode(p.x, p.y, 22, "255,80,110");
    if (p.health <= 0) {
      p.health = 0;
      this.gameOver();
    }
  }

  private gameOver() {
    this.explode(this.p.x, this.p.y, 60, "255,120,160");
    this.explode(this.p.x, this.p.y, 40, "255,200,120");
    this.addShake(28);
    this.flash = 1;
    this.flashColor = "255,80,110";
    const s = Math.floor(this.score);
    this.best = Math.max(this.best, s);
    this.saveScore(s);
    this.setState("gameover");
  }

  private explode(x: number, y: number, n: number, color: string) {
    for (let i = 0; i < n; i++) {
      const a = rand(0, Math.PI * 2);
      const sp = rand(60, 420);
      this.particles.push({
        x,
        y,
        vx: Math.cos(a) * sp,
        vy: Math.sin(a) * sp,
        life: rand(0.3, 0.9),
        maxLife: 0.9,
        size: rand(2, 6),
        color,
        glow: true,
        drag: 2.2,
      });
    }
  }

  private floatText(x: number, y: number, text: string, color: string) {
    this.floatTexts.push({ x, y, text, life: 0.9, color, vy: -50 });
    if (this.floatTexts.length > 40) this.floatTexts.shift();
  }

  private addShake(v: number) {
    this.shake = Math.min(40, this.shake + v);
  }

  // ---------- highscores ----------
  private loadBest(): number {
    const l = this.loadScores();
    return l.length ? l[0] : 0;
  }
  loadScores(): number[] {
    try {
      const raw = localStorage.getItem(HS_KEY);
      if (!raw) return [];
      const arr = JSON.parse(raw);
      if (Array.isArray(arr)) return arr.filter((n) => typeof n === "number").sort((a, b) => b - a);
    } catch {
      /* ignore */
    }
    return [];
  }
  private saveScore(s: number) {
    const l = this.loadScores();
    l.push(s);
    l.sort((a, b) => b - a);
    const top = l.slice(0, 5);
    try {
      localStorage.setItem(HS_KEY, JSON.stringify(top));
    } catch {
      /* ignore */
    }
  }

  // ---------- render ----------
  private render() {
    const ctx = this.ctx;
    const { vw, vh, dpr } = this;
    ctx.setTransform(dpr, 0, 0, dpr, 0, 0);

    // background
    const bg = ctx.createLinearGradient(0, 0, 0, vh);
    bg.addColorStop(0, "#0a0b1e");
    bg.addColorStop(1, "#060612");
    ctx.fillStyle = bg;
    ctx.fillRect(0, 0, vw, vh);

    // screen shake offset
    if (this.shake > 0) {
      this.shakeX = rand(-this.shake, this.shake);
      this.shakeY = rand(-this.shake, this.shake);
    } else {
      this.shakeX = 0;
      this.shakeY = 0;
    }
    const camX = this.cam.x - vw / 2 + this.shakeX;
    const camY = this.cam.y - vh / 2 + this.shakeY;

    ctx.save();
    ctx.translate(-camX, -camY);

    this.drawStars(ctx, camX, camY);
    this.drawGrid(ctx, camX, camY);
    this.drawBounds(ctx);
    this.drawCrystals(ctx, camX, camY);
    this.drawParticles(ctx, camX, camY, false);
    this.drawEnemies(ctx, camX, camY);
    this.drawPlayer(ctx);
    this.drawParticles(ctx, camX, camY, true);
    this.drawFloatTexts(ctx);

    ctx.restore();

    // vignette
    const vg = ctx.createRadialGradient(vw / 2, vh / 2, Math.min(vw, vh) * 0.3, vw / 2, vh / 2, Math.max(vw, vh) * 0.75);
    vg.addColorStop(0, "rgba(0,0,0,0)");
    vg.addColorStop(1, "rgba(0,0,0,0.55)");
    ctx.fillStyle = vg;
    ctx.fillRect(0, 0, vw, vh);

    // damage / hit flash
    if (this.flash > 0) {
      ctx.fillStyle = `rgba(${this.flashColor},${this.flash * 0.5})`;
      ctx.fillRect(0, 0, vw, vh);
    }

    this.drawMinimap(ctx);
    this.drawJoystick(ctx);
  }

  private drawStars(ctx: CanvasRenderingContext2D, camX: number, camY: number) {
    ctx.save();
    for (const s of this.stars) {
      // parallax: nearer stars move more
      const px = this.cam.x * (1 - s.z) * 0.5;
      const py = this.cam.y * (1 - s.z) * 0.5;
      const x = s.x + px;
      const y = s.y + py;
      if (x < camX - 20 || x > camX + this.vw + 20 || y < camY - 20 || y > camY + this.vh + 20) continue;
      ctx.globalAlpha = 0.3 + s.z * 0.6;
      ctx.fillStyle = s.z > 0.7 ? "#9fd8ff" : "#6a6ab0";
      ctx.fillRect(x, y, s.z * 2.2, s.z * 2.2);
    }
    ctx.restore();
  }

  private drawGrid(ctx: CanvasRenderingContext2D, camX: number, camY: number) {
    const step = 80;
    const x0 = Math.floor(camX / step) * step;
    const y0 = Math.floor(camY / step) * step;
    ctx.lineWidth = 1;
    ctx.strokeStyle = "rgba(90,120,220,0.10)";
    ctx.beginPath();
    for (let x = x0; x < camX + this.vw + step; x += step) {
      ctx.moveTo(x, camY);
      ctx.lineTo(x, camY + this.vh);
    }
    for (let y = y0; y < camY + this.vh + step; y += step) {
      ctx.moveTo(camX, y);
      ctx.lineTo(camX + this.vw, y);
    }
    ctx.stroke();
  }

  private drawBounds(ctx: CanvasRenderingContext2D) {
    ctx.save();
    ctx.strokeStyle = "rgba(120,150,255,0.45)";
    ctx.lineWidth = 4;
    ctx.shadowBlur = 24;
    ctx.shadowColor = "rgba(120,150,255,0.8)";
    ctx.strokeRect(-WORLD, -WORLD, WORLD * 2, WORLD * 2);
    ctx.restore();
  }

  private drawCrystals(ctx: CanvasRenderingContext2D, camX: number, camY: number) {
    ctx.save();
    for (const c of this.crystals) {
      if (!c.alive) continue;
      if (c.x < camX - 40 || c.x > camX + this.vw + 40 || c.y < camY - 40 || c.y > camY + this.vh + 40) continue;
      const s = (c.big ? 10 : 6) + Math.sin(c.phase) * 1.6;
      const col = c.big ? "255,220,120" : "120,240,255";
      ctx.globalAlpha = 1;
      ctx.shadowBlur = c.big ? 22 : 14;
      ctx.shadowColor = `rgba(${col},0.9)`;
      ctx.fillStyle = `rgba(${col},1)`;
      ctx.save();
      ctx.translate(c.x, c.y);
      ctx.rotate(c.phase * 0.5);
      ctx.beginPath();
      ctx.moveTo(0, -s);
      ctx.lineTo(s, 0);
      ctx.lineTo(0, s);
      ctx.lineTo(-s, 0);
      ctx.closePath();
      ctx.fill();
      ctx.fillStyle = "rgba(255,255,255,0.85)";
      ctx.beginPath();
      ctx.arc(0, 0, s * 0.35, 0, Math.PI * 2);
      ctx.fill();
      ctx.restore();
    }
    ctx.restore();
  }

  private drawParticles(ctx: CanvasRenderingContext2D, camX: number, camY: number, glowPass: boolean) {
    ctx.save();
    ctx.globalCompositeOperation = "lighter";
    for (const pt of this.particles) {
      if (pt.glow !== glowPass) continue;
      if (pt.x < camX - 20 || pt.x > camX + this.vw + 20 || pt.y < camY - 20 || pt.y > camY + this.vh + 20) continue;
      const a = clamp(pt.life / pt.maxLife, 0, 1);
      ctx.globalAlpha = a;
      ctx.fillStyle = `rgba(${pt.color},1)`;
      ctx.beginPath();
      ctx.arc(pt.x, pt.y, pt.size * (0.5 + a * 0.7), 0, Math.PI * 2);
      ctx.fill();
    }
    ctx.restore();
  }

  private drawEnemies(ctx: CanvasRenderingContext2D, camX: number, camY: number) {
    ctx.save();
    for (const e of this.enemies) {
      if (e.x < camX - 60 || e.x > camX + this.vw + 60 || e.y < camY - 60 || e.y > camY + this.vh + 60) {
        // draw off-screen indicator handled in minimap; skip
        continue;
      }
      const grow = e.spawn;
      const r = e.r * grow;
      ctx.save();
      ctx.translate(e.x, e.y);
      ctx.rotate(e.wobble * 0.5);
      // spawn ring
      if (e.spawn < 1) {
        ctx.globalAlpha = 1 - e.spawn;
        ctx.strokeStyle = "rgba(255,120,170,0.9)";
        ctx.lineWidth = 3;
        ctx.beginPath();
        ctx.arc(0, 0, e.r * (1.4 - e.spawn * 0.4) + 8, 0, Math.PI * 2);
        ctx.stroke();
        ctx.globalAlpha = 1;
      }
      const base = e.kind === "brute" ? "255,90,120" : "255,70,110";
      const col = e.hitFlash > 0.3 ? "255,255,255" : base;
      ctx.shadowBlur = 18;
      ctx.shadowColor = `rgba(${base},0.9)`;
      ctx.fillStyle = `rgba(${col},1)`;
      // spiky polygon
      const spikes = e.kind === "brute" ? 6 : 3;
      ctx.beginPath();
      for (let i = 0; i < spikes * 2; i++) {
        const ang = (i / (spikes * 2)) * Math.PI * 2;
        const rr = i % 2 === 0 ? r : r * 0.55;
        const x = Math.cos(ang) * rr;
        const y = Math.sin(ang) * rr;
        if (i === 0) ctx.moveTo(x, y);
        else ctx.lineTo(x, y);
      }
      ctx.closePath();
      ctx.fill();
      // core
      ctx.shadowBlur = 0;
      ctx.fillStyle = "rgba(20,0,10,0.9)";
      ctx.beginPath();
      ctx.arc(0, 0, r * 0.4, 0, Math.PI * 2);
      ctx.fill();
      ctx.fillStyle = "rgba(255,230,240,0.95)";
      ctx.beginPath();
      ctx.arc(0, 0, r * 0.16, 0, Math.PI * 2);
      ctx.fill();
      ctx.restore();
      // hp bar for brute
      if (e.kind === "brute" && e.hp < e.maxHp && e.spawn >= 1) {
        ctx.fillStyle = "rgba(0,0,0,0.5)";
        ctx.fillRect(e.x - 18, e.y - e.r - 12, 36, 5);
        ctx.fillStyle = "rgba(255,120,150,1)";
        ctx.fillRect(e.x - 18, e.y - e.r - 12, 36 * (e.hp / e.maxHp), 5);
      }
    }
    ctx.restore();
  }

  private drawPlayer(ctx: CanvasRenderingContext2D) {
    const p = this.p;
    ctx.save();
    ctx.translate(p.x, p.y);
    ctx.rotate(p.angle);

    // dash aura
    if (p.dashing > 0) {
      ctx.globalAlpha = p.dashing / 0.22;
      ctx.fillStyle = "rgba(140,210,255,0.35)";
      ctx.beginPath();
      ctx.arc(0, 0, p.r + 14, 0, Math.PI * 2);
      ctx.fill();
      ctx.globalAlpha = 1;
    }

    const blink = p.invuln > 0 && Math.floor(p.invuln * 20) % 2 === 0;
    ctx.globalAlpha = blink ? 0.4 : 1;

    ctx.shadowBlur = 20;
    ctx.shadowColor = "rgba(255,140,80,0.9)";
    // ship body triangle
    const grad = ctx.createLinearGradient(-p.r, 0, p.r, 0);
    grad.addColorStop(0, "#ff5f6d");
    grad.addColorStop(1, "#ffc371");
    ctx.fillStyle = grad;
    ctx.beginPath();
    ctx.moveTo(p.r + 4, 0);
    ctx.lineTo(-p.r, -p.r * 0.8);
    ctx.lineTo(-p.r * 0.5, 0);
    ctx.lineTo(-p.r, p.r * 0.8);
    ctx.closePath();
    ctx.fill();
    // cockpit
    ctx.shadowBlur = 0;
    ctx.fillStyle = "rgba(255,255,255,0.9)";
    ctx.beginPath();
    ctx.arc(2, 0, p.r * 0.28, 0, Math.PI * 2);
    ctx.fill();
    ctx.restore();
  }

  private drawFloatTexts(ctx: CanvasRenderingContext2D) {
    ctx.save();
    ctx.textAlign = "center";
    for (const f of this.floatTexts) {
      const a = clamp(f.life / 0.9, 0, 1);
      ctx.globalAlpha = a;
      ctx.font = "bold 16px ui-sans-serif, system-ui, sans-serif";
      ctx.fillStyle = `rgba(${f.color},1)`;
      ctx.shadowBlur = 8;
      ctx.shadowColor = `rgba(${f.color},0.8)`;
      ctx.fillText(f.text, f.x, f.y);
    }
    ctx.restore();
  }

  private drawMinimap(ctx: CanvasRenderingContext2D) {
    if (this.state !== "playing" && this.state !== "paused") return;
    const size = Math.min(120, this.vw * 0.26);
    const pad = 14;
    const x = this.vw - size - pad;
    const y = pad + 4;
    const scale = size / (WORLD * 2);
    ctx.save();
    ctx.globalAlpha = 0.85;
    ctx.fillStyle = "rgba(8,10,26,0.7)";
    ctx.strokeStyle = "rgba(120,150,255,0.4)";
    ctx.lineWidth = 1.5;
    this.roundRect(ctx, x, y, size, size, 8);
    ctx.fill();
    ctx.stroke();
    ctx.beginPath();
    this.roundRect(ctx, x, y, size, size, 8);
    ctx.clip();
    const cx = (wx: number) => x + (wx + WORLD) * scale;
    const cy = (wy: number) => y + (wy + WORLD) * scale;
    // crystals (sample)
    ctx.fillStyle = "rgba(120,240,255,0.7)";
    for (let i = 0; i < this.crystals.length; i += 3) {
      const c = this.crystals[i];
      if (!c.alive) continue;
      ctx.fillRect(cx(c.x), cy(c.y), 1.4, 1.4);
    }
    // enemies
    ctx.fillStyle = "rgba(255,90,120,0.95)";
    for (const e of this.enemies) {
      ctx.fillRect(cx(e.x) - 1, cy(e.y) - 1, 2.4, 2.4);
    }
    // player
    ctx.fillStyle = "rgba(255,200,120,1)";
    ctx.beginPath();
    ctx.arc(cx(this.p.x), cy(this.p.y), 2.6, 0, Math.PI * 2);
    ctx.fill();
    ctx.restore();
  }

  private roundRect(ctx: CanvasRenderingContext2D, x: number, y: number, w: number, h: number, r: number) {
    ctx.beginPath();
    ctx.moveTo(x + r, y);
    ctx.arcTo(x + w, y, x + w, y + h, r);
    ctx.arcTo(x + w, y + h, x, y + h, r);
    ctx.arcTo(x, y + h, x, y, r);
    ctx.arcTo(x, y, x + w, y, r);
    ctx.closePath();
  }

  private drawJoystick(ctx: CanvasRenderingContext2D) {
    if (!this.joyActive) return;
    ctx.save();
    ctx.globalAlpha = 0.5;
    ctx.strokeStyle = "rgba(160,190,255,0.8)";
    ctx.fillStyle = "rgba(120,150,255,0.15)";
    ctx.lineWidth = 2;
    ctx.beginPath();
    ctx.arc(this.joyBase.x, this.joyBase.y, 60, 0, Math.PI * 2);
    ctx.fill();
    ctx.stroke();
    ctx.globalAlpha = 0.8;
    ctx.fillStyle = "rgba(180,210,255,0.6)";
    ctx.beginPath();
    ctx.arc(this.joyKnob.x, this.joyKnob.y, 26, 0, Math.PI * 2);
    ctx.fill();
    ctx.restore();
  }
}

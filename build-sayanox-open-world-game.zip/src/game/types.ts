export type GameState = "menu" | "playing" | "paused" | "gameover";

export interface Stats {
  score: number;
  best: number;
  combo: number;
  comboTimer: number; // 0..1 fraction remaining
  health: number;
  maxHealth: number;
  dash: number; // 0..1 readiness
  time: number; // seconds survived
  wave: number;
}

export type StatsCallback = (s: Stats) => void;
export type StateCallback = (s: GameState) => void;
